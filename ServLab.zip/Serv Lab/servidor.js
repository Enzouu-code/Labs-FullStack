require("colors");

var http = require("http");
var express = require("express");
var bodyParser = require("body-parser");
var mongodb = require("mongodb");

const MongoClient = mongodb.MongoClient;
const ObjectId = mongodb.ObjectId;

const uri = "mongodb://enzo:Enzo210807@ac-lkx8xoy-shard-00-00.jltwsky.mongodb.net:27017,ac-lkx8xoy-shard-00-01.jltwsky.mongodb.net:27017,ac-lkx8xoy-shard-00-02.jltwsky.mongodb.net:27017/?ssl=true&replicaSet=atlas-evx3kv-shard-0&authSource=admin&appName=Cluster0";

const client = new MongoClient(uri);

var app = express();

app.use(express.static("./public"));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.set("view engine", "ejs");
app.set("views", "./views");

var server = http.createServer(app);
server.listen(80);
console.log("Servidor rodando...".rainbow);

// ======================
// ROTAS
// ======================

app.get("/", function(req, resp) {
    resp.sendFile(__dirname + "/public/projects.html");
});

// LOGIN

app.get("/login", function(req, resp) {
    resp.sendFile(__dirname + "/public/LabOito/login.html");
});

// CADASTRO USUARIO

app.get("/cadastro", function(req, resp) {
    resp.sendFile(__dirname + "/public/LabOito/cadastro.html");
});

// BLOG

app.get("/blog/cadastrar", function(req, resp) {
    resp.sendFile(__dirname + "/public/blog/cadastrar_post.html");
});

// CARROS

app.get("/carros/cadastrar", function(req, resp) {
    resp.sendFile(__dirname + "/public/carros/cadastrar_carro.html");
});

// ======================
// MONGODB
// ======================

console.log("Tentando conectar ao MongoDB...".yellow);
client.connect()
.then(function() {
    console.log("MongoDB conectado!".green);
    var dbo = client.db("exemplo_bd");
    var usuarios = dbo.collection("usuarios");
    var posts = dbo.collection("posts");
    var carros = dbo.collection("carros");

    // ======================
    // CADASTRAR USUARIO
    // ======================

    app.post("/cadastrar_usuario", function(req, resp) {
        console.log(req.body);
        var data = {
            db_nome: req.body.nome,
            db_login: req.body.login,
            db_senha: req.body.senha
        };

        usuarios.insertOne(data)
        .then(function() {
            resp.render("resposta", {
                resposta: "Usuário cadastrado com sucesso!"
            });
        })

        .catch(function(err) {
            console.log(err);
            resp.render("resposta", {
                resposta: "Erro ao cadastrar usuário!"
            });
        });
    });

    // ======================
    // LOGIN
    // ======================

    app.post("/logar_usuario", function(req, resp) {
        var data = {
            db_login: req.body.login,
            db_senha: req.body.senha
        };

        usuarios.find(data).toArray()
        .then(function(items) {
            if(items.length == 0) {
                resp.render("resposta", {
                    resposta: "Usuário ou senha inválidos!"
                });

            } else {
                resp.render("resposta", {
                    resposta: "Login realizado com sucesso!"
                });
            }
        })

        .catch(function(err) {
            console.log(err);
            resp.render("resposta", {
                resposta: "Erro ao logar usuário!"
            });
        });
    });

    // ======================
    // CADASTRAR POST
    // ======================

    app.post("/cadastrar_post", function(req, resp) {
        var data = {
            db_titulo: req.body.titulo,
            db_resumo: req.body.resumo,
            db_conteudo: req.body.conteudo
        };

        posts.insertOne(data)
        .then(function() {
            resp.render("resposta", {
                resposta: "Post cadastrado com sucesso!"
            });
        })

        .catch(function(err) {
            console.log(err);
            resp.render("resposta", {
                resposta: "Erro ao cadastrar post!"
            });
        });
    });

    // ======================
    // BLOG
    // ======================

    app.get("/blog", function(req, resp) {
        posts.find().toArray()
        .then(function(items) {

            resp.render("blog", {
                posts: items
            });
        })

        .catch(function(err) {
            console.log(err);
            resp.send("Erro ao buscar posts!");
        });
    });

    // ======================
    // LISTAR CARROS
    // ======================

    app.get("/carros", function(req, resp) {
        carros.find().toArray()
        .then(function(items) {
            resp.render("carros", {
                carros: items
            });
        })
        .catch(function(err) {
            console.log(err);
            resp.send("Erro ao buscar carros!");
        });
    });

    // ======================
    // GERENCIAR CARROS
    // ======================

    app.get("/gerenciar_carros", function(req, resp) {
        carros.find().toArray()
        .then(function(items) {
            resp.render("gerenciar_carros", {
                carros: items
            });
        })
        .catch(function(err) {
            console.log(err);
            resp.send("Erro!");
        });
    });

    // ======================
    // CADASTRAR CARRO
    // ======================

    app.post("/cadastrar_carro", function(req, resp) {
        var data = {
            db_marca: req.body.marca,
            db_modelo: req.body.modelo,
            db_ano: req.body.ano,
            db_qtde: parseInt(req.body.qtde)
        };
        carros.insertOne(data)
        .then(function() {
            resp.redirect("/gerenciar_carros");
        })
        .catch(function(err) {
            console.log(err);
            resp.send("Erro ao cadastrar carro!");
        });
    });

    // ======================
    // DELETAR CARRO
    // ======================

    app.get("/deletar_carro/:id", function(req, resp) {
        var id = req.params.id;
        carros.deleteOne({
            _id: new ObjectId(id)
        })
        .then(function() {
            resp.redirect("/gerenciar_carros");
        })

        .catch(function(err) {
            console.log(err);
            resp.send("Erro ao deletar!");
        });
    });

    // ======================
    // EDITAR CARRO
    // ======================

    app.get("/editar_carro/:id", function(req, resp) {
        var id = req.params.id;

        carros.findOne({
            _id: new ObjectId(id)
        })
        .then(function(item) {
            resp.render("editar_carro", {
                carro: item
            });
        })
        .catch(function(err) {
            console.log(err);
            resp.send("Erro!");
        });
    });

    // ======================
    // ATUALIZAR CARRO
    // ======================

    app.post("/atualizar_carro/:id", function(req, resp) {
        var id = req.params.id;
        var data = {
            db_marca: req.body.marca,
            db_modelo: req.body.modelo,
            db_ano: req.body.ano,
            db_qtde: parseInt(req.body.qtde)
        };
        carros.updateOne(
            { _id: new ObjectId(id) },
            { $set: data }
        )
        .then(function() {
            resp.redirect("/gerenciar_carros");
        })
        .catch(function(err) {
            console.log(err);
            resp.send("Erro ao atualizar!");
        });
    });

    // ======================
    // VENDER CARRO
    // ======================

    app.get("/vender_carro/:id", function(req, resp) {
        var id = req.params.id;
        carros.findOne({
            _id: new ObjectId(id)
        })
        .then(function(item) {
            if(item.db_qtde > 0) {
                carros.updateOne(
                    { _id: new ObjectId(id) },

                    {
                        $set: {
                            db_qtde: item.db_qtde - 1
                        }
                    }
                )

                .then(function() {
                    resp.redirect("/carros");
                });

            } else {
                resp.send("ESGOTADO");
            }
        })

        .catch(function(err) {
            console.log(err);
            resp.send("Erro!");
        });
    });
})

.catch(function(err) {
    console.log("ERRO AO CONECTAR NO MONGODB:".red, err.message);
});
require("colors");

var http = require("http");
var express = require("express");
var bodyParser = require("body-parser");
var mongodb = require("mongodb");

const MongoClient = mongodb.MongoClient;

const uri = "mongodb://enzo:Enzo210807@ac-lkx8xoy-shard-00-00.jltwsky.mongodb.net:27017,ac-lkx8xoy-shard-00-01.jltwsky.mongodb.net:27017,ac-lkx8xoy-shard-00-02.jltwsky.mongodb.net:27017/?ssl=true&replicaSet=atlas-evx3kv-shard-0&authSource=admin&appName=Cluster0";

const client = new MongoClient(uri);

var app = express();

app.use(express.static("./public"));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.set("view engine", "ejs");
app.set("views", "./views");

var server = http.createServer(app);

server.listen(80);

console.log("Servidor rodando...".rainbow);

// ROTAS

app.get("/", function(req, resp) {
    resp.redirect("/login");
});

app.get("/login", function(req, resp) {
    resp.sendFile(__dirname + "/public/LabOito/login.html");
});

app.get("/cadastro", function(req, resp) {
    resp.sendFile(__dirname + "/public/LabOito/cadastro.html");
});

// MONGODB

console.log("Tentando conectar ao MongoDB...".yellow);

client.connect()
.then(function() {

    console.log("MongoDB conectado!".green);

    var dbo = client.db("exemplo_bd");

    var usuarios = dbo.collection("usuarios");

    // CADASTRO

    app.post("/cadastrar_usuario", function(req, resp) {

        console.log(req.body);

        var data = {
            db_nome: req.body.nome,
            db_login: req.body.login,
            db_senha: req.body.senha
        };

        console.log("Tentando cadastrar:", data);

        usuarios.insertOne(data)

        .then(function() {

            resp.render("resposta", {
                resposta: "Usuário cadastrado com sucesso!"
            });

        })

        .catch(function(err) {

            console.log("Erro ao cadastrar:".red, err);

            resp.render("resposta", {
                resposta: "Erro ao cadastrar usuário!"
            });

        });

    });

    // LOGIN

    app.post("/logar_usuario", function(req, resp) {

        console.log(req.body);

        var data = {
            db_login: req.body.login,
            db_senha: req.body.senha
        };

        console.log("Tentando logar:", data);

        usuarios.find(data).toArray()

        .then(function(items) {

            console.log("Resultado:", items);

            if(items.length == 0) {

                resp.render("resposta", {
                    resposta: "Usuário ou senha inválidos!"
                });

            } else {

                resp.render("resposta", {
                    resposta: "Login realizado com sucesso!"
                });

            }

        })

        .catch(function(err) {

            console.log("Erro ao logar:".red, err);

            resp.render("resposta", {
                resposta: "Erro ao logar usuário!"
            });

        });

    });

})

.catch(function(err) {

    console.log("ERRO AO CONECTAR NO MONGODB:".red, err.message);

});